package entites;

public class Moto extends Vehiculo{

    private String marca;
    private String modelo;
    private String cilindrada;
    private double precio;

    public Moto(String marca, String modelo, String cilindrada, double precio) {
        super(marca, modelo, cilindrada, precio);
        this.marca=marca;
        this.modelo=modelo;
        this.cilindrada=cilindrada;
        this.precio=precio;
    }

    @Override
    public String toString() {
        return "Marca: " + marca + " // Modelo: " + modelo + " // Cilindrada: " + cilindrada + " // Precio: $" + df.format(precio);
    }
    
}
