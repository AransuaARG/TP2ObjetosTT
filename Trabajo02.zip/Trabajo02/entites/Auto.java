package entites;

public class Auto extends Vehiculo{

    private String marca;
    private String modelo;
    private int puerta;
    private double precio;

    public Auto(String marca, String modelo, int puerta, double precio) {
        super(marca, modelo, puerta, precio);
        this.marca=marca;
        this.modelo=modelo;
        this.puerta=puerta;
        this.precio=precio;
    }

    @Override
    public String toString() {
        return "Marca: " + marca + " // Modelo: " + modelo + " // Puertas: " + puerta + " // Precio: $" + df.format(precio);
    }

}
