package entites;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {

    private String marca;
    private String modelo;
    private int puerta;
    private String cilindrada;
    private double precio;
    
    public Vehiculo(String marca, String modelo, int puerta, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.puerta = puerta;
        this.precio = precio;
    }
    
    public Vehiculo(String marca, String modelo, String cilindrada, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.cilindrada = cilindrada;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPuerta() {
        return puerta;
    }

    public void setPuerta(int puerta) {
        this.puerta = puerta;
    }

    public String getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    public int compareTo(Vehiculo para){
        String thisVehiculo = this.getMarca() + this.getModelo() + this.getPrecio();
        String paraVehiculo = para.getMarca() + para.getModelo() + para.getPrecio();
        return thisVehiculo.compareTo(paraVehiculo);
    }

    DecimalFormat df = new DecimalFormat("#,##0.00");

    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", puerta=" + puerta + ", cilindrada=" + cilindrada
                + ", precio=" + precio + "]";
    }

}
