package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import entites.Auto;
import entites.Moto;
import entites.Vehiculo;

public class TestVehiculo {
    public static void main(String[] args) {
        
        System.out.println("Lista de Vehículos:");
        List<Vehiculo> vehiculos = new ArrayList<>();
        vehiculos.add(new Auto("Peugeot", "206", 4, 200000));
        vehiculos.add(new Moto("Honda", "Titan", "125c", 60000));
        vehiculos.add(new Auto("Peugeot", "208", 5, 250000));
        vehiculos.add(new Moto("Yamaha", "YBR", "160c", 80500.50));

        vehiculos.stream().forEach(System.out::println);

        System.out.println("==========================================");

        System.out.println("Vehículo más caro:");
        double precioMax = vehiculos.stream().max(Comparator.comparingDouble(Vehiculo::getPrecio)).get().getPrecio();
        vehiculos.stream().filter(vehiculo->vehiculo.getPrecio()==precioMax).forEach(System.out::println);

        System.out.println("Vehículo más barato:");
        double precioMin = vehiculos.stream().min(Comparator.comparingDouble(Vehiculo::getPrecio)).get().getPrecio();
        vehiculos.stream().filter(vehiculo->vehiculo.getPrecio()==precioMin).forEach(System.out::println);

        System.out.println("Vehículo que contiene en el modelo la letra 'Y':");
        vehiculos.stream().filter(vehiculo->vehiculo.getModelo().toUpperCase().startsWith("Y")).forEach(System.out::println);

        System.out.println("==========================================");

        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos.stream().sorted(Comparator.comparing(Vehiculo::getPrecio).reversed()).forEach(System.out::println);

        System.out.println("==========================================");

        List <Vehiculo> ordenNatural = new ArrayList<>();
        for(Vehiculo vehiculo : vehiculos) ordenNatural.add(vehiculo);
        vehiculos.forEach(o->{
            if(o instanceof Vehiculo) ordenNatural.add((Vehiculo)o);
        });

        Set<Vehiculo> setVehiculos=null;
        setVehiculos = new TreeSet();
        setVehiculos.addAll(ordenNatural);

        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        setVehiculos.forEach(System.out::println);
        
    }

}
